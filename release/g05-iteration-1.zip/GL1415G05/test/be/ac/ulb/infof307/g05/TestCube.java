package be.ac.ulb.infof307.g05;

public class TestCube {

}
